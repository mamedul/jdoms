# jDoms changelog

## Version 1.0.1(January 13, 2021)
* Fixed a function( `jDoms.isEmpty(variable)` )
* Add a function( `jDoms.isInt(variable)` )

## Version 1.0.0 (November 7th, 2021)-Initial Release
* Upload and public release the initial version.